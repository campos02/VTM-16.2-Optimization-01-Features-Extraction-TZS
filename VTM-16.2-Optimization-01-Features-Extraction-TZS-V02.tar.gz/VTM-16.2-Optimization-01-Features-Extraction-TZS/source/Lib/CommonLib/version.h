#if ! defined( VTM_VERSION )
#define VTM_VERSION "16.2"
#endif
